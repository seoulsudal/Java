import java.util.Scanner;

public class TimeConversion {

	public static void main(String[] args) {
		
		// 스캐너 생성
		Scanner input = new Scanner(System.in);
		
		// 변수 선언
		int totalSecond;	// 총 초
		int hour;			// 시
		int minute;			// 분
		int second;			// 초
		
		System.out.println("입력 받은 시간을 초로 변환하는 프로그램");
		
		// 시 입력
		System.out.println("시를 입력하세요.");
		hour = input.nextInt();
		
		// 시 확인
		if (hour < 0) {
			System.out.println("시를 0이상 입력해주세요.");
		}
		
		// 분 입력
		System.out.println("분을 입력하세요.");
		minute = input.nextInt();
		
		// 분 확인
		if (minute < 0 || minute > 60) {
			System.out.println("분을 0이상 60이하로 입력해주세요.");
		}
		
		// 초 입력
		System.out.println("초를 입력하세요.");
		second = input.nextInt();
		
		// 초 확인
		if (second < 0 || second > 60) {
			System.out.println("초를 0이상 60이하로 입력해주세요.");
		}
		
		// 결과 출력
		if (hour >= 0 && (minute >= 0 && minute <= 60) && (second >= 0 && second <=60)) {
			// 총 초 계산
			totalSecond = ( hour * 3600 ) + ( minute * 60 ) + second;	//총 초시간 = (시간*3600) + (분*60) + 초
			System.out.println(hour+"시간 "+minute+"분 "+second+"초는 총 "+totalSecond+"초 이다.");
		}
		else {
			System.out.println("재시작하여 값을 다시 입력해주세요.");
		}
		
	}

}
